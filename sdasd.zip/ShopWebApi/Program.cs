using FluentScheduler;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using ShopWebApi.Domain.Job;

namespace ShopWebApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
            JobManager.Initialize();
            JobManager.AddJob<JobReserv>(s => s.ToRunNow().AndEvery(3).Seconds());
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
