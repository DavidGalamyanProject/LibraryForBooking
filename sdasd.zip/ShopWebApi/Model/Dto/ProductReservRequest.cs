﻿namespace ShopWebApi.Model.Dto
{
    /// <summary>   </summary>
    public class ProductReservRequest
    {
        public string ProductName { get; set; }
        public int Quantity { get; set; }
    }
}
